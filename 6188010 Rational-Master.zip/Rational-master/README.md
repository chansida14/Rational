# Rational
A repository for students to practice how to create JUnit test cases using different build technologies including ant, Maven, and Gradle.
